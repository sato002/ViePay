var CaptchaApiKey = "OAXsOcsXdogbkZDObzfhmpKfMHypyTBaJNKyDvB9ypZx2wDm6vsT2rq131qQIfbQ6XZlruUEaOxi9xmf";

chrome.storage.local.get(["CaptchaApiKey"]).then((result) => {
  if(result && result.CaptchaApiKey) {
	CaptchaApiKey = result.CaptchaApiKey;
  }
});



const toDataURL = url => fetch(url, {
        "mode": "no-cors"
    })
    .then(response => response.blob())
    .then(blob => new Promise((resolve, reject) => {
        const reader = new FileReader()
        reader.onloadend = () => resolve(reader.result)
        reader.onerror = reject
        reader.readAsDataURL(blob)
    }));

function createCaptchaJob(innerImgBase64, outerImgBase64) {
	return fetch('https://omocaptcha.com/api/createJob', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            "api_token": CaptchaApiKey,
            "data": {
                "type_job_id": "23",
                "image_base64": innerImgBase64 + '|' + outerImgBase64
            }
        })
    })
}

function getCaptchaJobResult(job_id) {
	return fetch('https://omocaptcha.com/api/getJobResult', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            "api_token": CaptchaApiKey,
            "job_id": job_id
        })
    });
}

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        debugger
        console.log(sender.tab ?
            "from a content script:" + sender.tab.url :
            "from the extension");

        if (sender.tab) {
            if (request.method === "GetCaptchaResult") {
                toDataURL(request.data.innerImgSrc).then(innerBase64 => {
                        console.log(innerBase64);
                        toDataURL(request.data.outerImgSrc).then(outerBase64 => {
                                console.log(outerBase64);
                                var innerBase64Split = innerBase64.split(',');
                                var outerBase64Split = outerBase64.split(',');

                                if (innerBase64Split.length === 2 && outerBase64Split.length === 2) {
                                    var innerImgBase64 = innerBase64Split[1];
                                    var outerImgBase64 = outerBase64Split[1];

									createCaptchaJob(innerImgBase64, outerImgBase64)
									.then(res => res.json())
									.then(res => {
										if (res && !res.error) {
											getCaptchaJobResult(res.job_id)
											.then(res => res.json())
											.then(res => {
												if (res && !res.error && res.status === "success") {
													sendResponse({
														status: "success",
														data: {
															result: res.result
														}
													});
												}
												else {
													sendResponse({
														status: "error",
														errorMessage: "Lỗi lấy kết quả job captcha" + JSON.stringify(res)
													});
												}
											});
										}
										else {
											sendResponse({
                                                status: "error",
                                                errorMessage: "Lỗi tạo job captcha" + JSON.stringify(res)
                                            });
										}
									})
                                } else {
                                    sendResponse({
                                        status: "error",
                                        errorMessage: "Lỗi split base 64"
                                    });
                                }
                            },
                            err => sendResponse({
                                status: "error",
                                errorMessage: "Lỗi giải base64"
                            })
                        )
                    },
                    err => sendResponse({
                        status: "error",
                        errorMessage: "Lỗi giải base64"
                    })
                )

                return true;
            }
        }
		else {
			if (request.method === "SaveConfig") {
				debugger
				CaptchaApiKey = request.data.captchaApiKey;
				console.log(CaptchaApiKey);
				chrome.storage.local.set({ "CaptchaApiKey": CaptchaApiKey }).then(() => {
				  console.log("Value is set");
				});
				sendResponse({
						status: "success"
					});
			}
		}
    }
);