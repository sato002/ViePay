$(document).ready(function() {
	console.log("popup loaded");
	
	$('#btnSaveConfig').on('click', function(e) {
		debugger
		e.preventDefault();
		saveConfig($('#apiKey').val());
	});
	debugger
	chrome.storage.local.get(["CaptchaApiKey"]).then((result) => {
	  if(result) {
		$('#apiKey').val(result.CaptchaApiKey || '');
	  }
	});
});

function saveConfig(apiKey) {
	chrome.runtime.sendMessage({method: "SaveConfig", data: { captchaApiKey: apiKey }},
		function (response) {
			tabURL = response.navURL;
			$("#tabURL").text(tabURL);
		}
	);
}