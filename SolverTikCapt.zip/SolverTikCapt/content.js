$(document).ready(function() {
	setTimeout(detectCaptcha, 2000);
});

async function detectCaptcha() {
	if($('[data-testid="whirl-outer-img"]').length > 0) {
		debugger
		
		var innerImgSrc = $('[data-testid="whirl-inner-img"]').attr('src');
		var outerImgSrc = $('[data-testid="whirl-outer-img"]').attr('src');
		
		console.log(innerImgSrc);
		console.log(outerImgSrc);
		
		const response = await chrome.runtime.sendMessage({method: "GetCaptchaResult", data: {
			"innerImgSrc": innerImgSrc,
			"outerImgSrc": outerImgSrc
		}});
		// do something with response here, not outside the function
		console.log(response);
		if(response && response.status === "success" && response.data) {
			
		}
	}
	else {
		setTimeout(detectCaptcha, 2000);
	}
}

async function detectCaptcha2() {
		innerImgSrc = 'https://p16-security-va.ibyteimg.com/img/security-captcha-oversea-usa/whirl_346c53577ad5d448efa159608be75aa6f1c4c07f_2.png~tplv-obj.image';
		outerImgSrc = 'https://p16-security-va.ibyteimg.com/img/security-captcha-oversea-usa/whirl_346c53577ad5d448efa159608be75aa6f1c4c07f_1.png~tplv-obj.image';
		
		const response = await chrome.runtime.sendMessage({method: "GetCaptchaResult", data: {
			"innerImgSrc": innerImgSrc,
			"outerImgSrc": outerImgSrc
		}});
		// do something with response here, not outside the function
		console.log(response);
}
